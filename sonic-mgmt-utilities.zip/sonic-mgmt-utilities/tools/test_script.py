# Copyright (c) 2023 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

#!/usr/bin/env python3
# Copyright (c) 2022 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

from __future__ import absolute_import, division, print_function

from abc import ABC, abstractmethod
import argparse
from dataclasses import dataclass
from datetime import datetime, timedelta
import os
import prettytable
import re
import xml.etree.ElementTree as ET
import Arjob
import Tac

@dataclass
class Config:
   statusAllowRe : str
   statusDenyRe : str
   fileAllowRe : str
   fileDenyRe : str
   testAllowRe : str
   testDenyRe : str
   detail : bool
   quietHeader : bool
   quietSummary : bool
   summaryOnly: bool
   wide : bool
   trFile : str

   uploadArjob : bool
   uploadProject : str
   uploadOwner : str
   uploadSonicTestServer: str

class ConfigFactory( ABC ):
   @abstractmethod
   def config( self ):
      pass

class ArgProcessor( ConfigFactory ):
   def __init__( self ):
      parser = argparse.ArgumentParser()
      parser.add_argument( '-s', '--statusAllow',
                           help='status regex to filter and allow' )
      parser.add_argument( '-sd', '--statusDeny',
                           help='status regex to filter and deny' )
      parser.add_argument( '-f', '--fileAllow',
                           help='filename to filter and allow' )
      parser.add_argument( '-fd', '--fileDeny',
                           help='filename to filter and deny' )
      parser.add_argument( '-t', '--testAllow',
                           help='testname to filter and allow' )
      parser.add_argument( '-td', '--testDeny',
                           help='testname to filter and deny' )
      parser.add_argument( '-d', '--detail', action='store_true',
                           help='Show the full detailed message' )
      parser.add_argument( '-q', '--quiet', action='store_true',
                           help='Omit results summary' )
      parser.add_argument( '-qq', '--quietquiet', action='store_true',
                           help='Omit headers and the results summary' )
      parser.add_argument( '-smry', '--summary', action='store_true',
                           help='Omit test results' )
      parser.add_argument( 'trfile',
                           help='tr.xml file name or directory to parse' )
      parser.add_argument( '-w', '--wide', action='store_true',
                           help='Wide output to not truncate column width' )

      parser.add_argument( '-u', '--uploadArjob', action='store_true',
                           help='Upload results to Arjob DB' )
      parser.add_argument( '--uploadProjectName',
                           help='Project name used in Arjob upload' )
      parser.add_argument( '--uploadSonicTestServerName',
                           help='SonicTestServer name used in Arjob upload' )
      parser.add_argument( '--uploadOwnerName',
                           help='Owner name used in Arjob upload' )

      self.args = parser.parse_args()

   def config( self ):
      quietHeader = self.args.quietquiet
      quietSummary = self.args.quiet or self.args.quietquiet
      return Config( statusAllowRe=self.args.statusAllow,
                     statusDenyRe=self.args.statusDeny,
                     fileAllowRe=self.args.fileAllow,
                     fileDenyRe=self.args.fileDeny,
                     testAllowRe=self.args.testAllow,
                     testDenyRe=self.args.testDeny,
                     detail=self.args.detail,
                     trFile=self.args.trfile,
                     quietHeader=quietHeader,
                     quietSummary=quietSummary,
                     wide=self.args.wide,
                     uploadArjob=self.args.uploadArjob,
                     uploadProject=self.args.uploadProjectName,
                     uploadOwner=self.args.uploadOwnerName,
                     uploadSonicTestServer=self.args.uploadSonicTestServerName,
                     summaryOnly=self.args.summary)

@dataclass
class TestCase:
   filename : str
   classname : str
   testname : str
   status : str
   start : datetime
   duration : timedelta
   message : str

class TestResultsProcessor( object ):
   def __init__( self, configFactory, resultsRenderer, summaryRenderer ):
      self.configFactory = configFactory
      self.resultsRenderer = resultsRenderer
      self.summaryRenderer = summaryRenderer

      self.config = self.configFactory.config()
      self.stats = { 'version' : '',
                     'topology' : '',
                     'host' : '',
                     'success' : 0,
                     'failure' : 0,
                     'skipped' : 0,
                     'error' : 0,
                     'runTime' : timedelta() }
      self.testCases = []

      self.processTrFile( self.config.trFile )

      if self.config.uploadArjob:
         au = ArjobUploader()
         au.upload( self.config.trFile,
                    self.config.uploadProject,
                    self.config.uploadSonicTestServer,
                    self.config.uploadOwner,
                   self.testCases, self.stats )

   def processTrFile( self, trFile ):
      for xmlFile in self.xmlFiles( trFile ):
         self.processXmlFile( xmlFile )
      self.renderSummary()
      if not self.config.summaryOnly:
         self.renderResults()

   def xmlFiles( self, trFile ):
      files = []
      if os.path.isdir( trFile ):
         for dirpath, dirnames, filenames in os.walk( trFile ):
            for filename in filenames:
               if filename.endswith( '.xml' ):
                  files.append( os.path.join( dirpath, filename ) )
      else:
         files.append( trFile )
      return files

   def processXmlFile( self, xmlFile ):
      content = ET.parse( xmlFile ).getroot()
      testsuite = content.find( 'testsuite' )
      if not testsuite:
         return
         #testsuite = content
      self.processXmlContent( testsuite )

   def processXmlContent( self, content ):
      timestamp = self.parseTestSuiteTimestamp( content )
      self.processTestSuiteProperties( content.find( 'properties' ) )
      self.processTestCases( timestamp, content.findall( 'testcase' ) )

   def parseTestSuiteTimestamp( self, testsuite ):
      timestamp = testsuite.get( 'timestamp' )
      t1 = datetime.strptime( timestamp, '%Y-%m-%dT%H:%M:%S.%f' )
      return t1

   def processTestSuiteProperties( self, properties ):
      if not properties:
         return
      version, topology, host = self.parseTestSuiteProperties( properties )
      self.updateSummary( version, topology, host )

   def parseTestSuiteProperties( self, properties ):
      version = ''
      topology = ''
      host = ''
      for prop in properties.findall( 'property' ):
         if prop.get( 'name' ) == 'os_version':
            version = prop.get( 'value' )
         if prop.get( 'name' ) == 'topology':
            topology = prop.get( 'value' )
         if prop.get( 'name' ) == 'host':
            host = prop.get( 'value' )
      return( version, topology, host )

   def updateSummary( self, version, topology, host ):
      if self.stats[ 'version' ] and version:
         assert self.stats[ 'version' ] == version

      if self.stats[ 'topology' ] and topology:
         assert self.stats[ 'topology' ] == topology

      if self.stats[ 'host' ] and host:
         assert self.stats[ 'host' ] == host

      self.stats[ 'version' ] = version
      self.stats[ 'topology' ] = topology
      self.stats[ 'host' ] = host

   def sortTestCasesByStartTime( self ):
      def startTime( testcase ):
         return testcase.start
      self.testCases.sort( key=startTime )

   def processTestCases( self, timestamp, testCases ):
      for tc in testCases:
         self.processTestCase( timestamp, tc )
      self.sortTestCasesByStartTime()

   def processTestCase( self, timestamp, tc ):
      testCase = self.parseTestCase( timestamp, tc )
      if self.testCaseIsAllowed( testCase ):
         self.updateStatsWithTestCase( testCase )
         self.testCases.append( testCase )

   def parseTestCase( self, timestamp, tc ):
      status, message = self.parseTestCaseStatusAndMessage( tc )
      start, duration = self.parseTestCaseStartAndDuration( tc )
      # some test cases do not have a start time. As a workaround just use the
      # testsuite timestamp
      if start is None:
         start = timestamp
      testCase = TestCase( filename=tc.get( 'file' ),
                           classname=tc.get( 'classname' ),
                           testname=tc.get( 'name' ),
                           status=status,
                           message=message,
                           start=start,
                           duration=duration )
      return testCase

   def parseTestCaseStatusAndMessage( self, tc ):
      # bool(xml.etree.ElementTree.Element ) can return False. Need to check
      # for 'is not None' to indicate not tag found
      status = 'success'
      message = ''
      failure = tc.find( 'failure' )
      if failure is not None:
         status = "failure"
         message = failure.get( 'message' )
      skipped = tc.find( 'skipped' )
      if skipped is not None:
         status = "skipped"
         message = skipped.get( 'message' )
      error = tc.find( 'error' )
      if error is not None:
         status = 'error'
         message = error.get( 'message' )
         if error.text:
            message = message + '\n==========================\n' + error.text
      return( status, message )

   def parseTestCaseStartAndDuration( self, tc ):
      delta = timedelta()
      properties = tc.find( 'properties' )
      if properties is None:
         return( None, delta )

      start = ''
      end = ''
      for prop in properties.findall( 'property' ):
         if prop.get( 'name' ) == 'start':
            start = prop.get( 'value' )
         if prop.get( 'name' ) == 'end' :
            end = prop.get( 'value' )

      if start and end:
         if '.' not in start:
            start = start + '.0'
         if '.' not in end:
            end = end + '.0'
         t1 = datetime.strptime( start, '%Y-%m-%d %H:%M:%S.%f' )
         t2 = datetime.strptime( end, '%Y-%m-%d %H:%M:%S.%f' )
         delta = t2 - t1
      return( t1, delta )

   def testCaseIsAllowed( self, testCase ):
      config = self.config
      allowRow = True
      if config.statusAllowRe:
         if not re.search( config.statusAllowRe, testCase.status ):
            allowRow = False
      if config.statusDenyRe:
         if re.search( config.statusDenyRe, testCase.status ):
            allowRow = False
      if config.fileAllowRe:
         if not re.search( config.fileAllowRe, testCase.filename ):
            allowRow = False
      if config.fileDenyRe:
         if re.search( config.fileDenyRe, testCase.filename ):
            allowRow = False
      if config.testAllowRe:
         if not re.search( config.testAllowRe, testCase.testname ):
            allowRow = False
      if config.testDenyRe:
         if re.search( config.testDenyRe, testCase.testname ):
            allowRow = False
      return allowRow

   def updateStatsWithTestCase( self, testCase ):
      self.stats[ testCase.status ] += 1
      self.stats[ 'runTime' ] += testCase.duration

   def renderResults( self ):
      self.resultsRenderer.detailIs( self.config.detail )
      self.resultsRenderer.quietIs( self.config.quietHeader )
      self.resultsRenderer.wideIs( self.config.wide )
      self.resultsRenderer.render( self.testCases )

   def renderSummary( self ):
      if self.config.quietSummary:
         return
      self.summaryRenderer.render( self.stats )

class TestResultsRenderer( object ):
   def __init__( self ):
      self.table = None
      self.detail = False
      self.columns = [ 'filename', 'classname', 'testname', 'status', 'start',
                       'duration', 'message' ]

      self.setupTable()

   def setupTable( self ):
      t = prettytable.PrettyTable( self.columns )
      t._max_width[ 'message' ] = 50
      for col in self.columns:
         t.align[ col ] = 'l'
      self.table = t

   def shortenCols( self, columnData ):
      return

   def detailIs( self, detail ):
      self.detail = detail

   def quietIs( self, quiet ):
      if not quiet:
         return

      t = self.table
      t.header = False
      t.hrules = prettytable.NONE
      t.vrules = prettytable.NONE

   def wideIs( self, wide ):
      t = self.table
      if not wide:
         t._max_width = { col: 20 for col in self.columns }

   def render( self, testCases ):
      for tc in testCases:
         colData = [ tc.filename,
                     tc.classname,
                     tc.testname,
                     tc.status,
                     str( tc.start ),
                     str( tc.duration ),
                     tc.message ]

         colDataToPrint = []
         if not self.detail:
            # limit all columns to thier max so that its all on oneline
            for index, col in enumerate( self.columns ):
               width = self.table._max_width.get( col, None )
               dataOrig = colData[ index ] or ""
               data = dataOrig[ : width ].split( '\n' )[ 0 ]
               colDataToPrint.append( data )
         else:
            colDataToPrint = colData
         self.table.add_row( colDataToPrint )
      print( self.table )

class TestSummaryRenderer( object ):
   def __init__( self ):
      self.table = None

   def setupTable( self ):
      t = prettytable.PrettyTable( [ 'Name', 'Value', 'Name2', 'Value2' ] )
      t.header = False
      t.align[ "Name" ] = "l"
      t.align[ "Value" ] = "r"
      t.align[ "Name2" ] = "l"
      t.align[ "Value2" ] = "l"
      self.table = t

   def render( self, stats ):
      self.setupTable()
      numPass = stats[ 'success' ]
      numFail = stats[ 'failure' ]
      numError = stats[ 'error' ]
      numSkip = stats[ 'skipped' ]
      runTime = stats[ 'runTime' ]

      numNotSkip = numPass + numFail + numError
      numTests = numNotSkip + numSkip
      passRate = str( numPass * 100 / numNotSkip if numNotSkip else 0 ) + '%'

      t = self.table
      t.add_row( [ 'Success', numPass, 'Version', stats[ 'version' ] ] )
      t.add_row( [ 'Failure', numFail, 'Topology', stats[ 'topology' ] ] )
      t.add_row( [ 'Skipped', numSkip, 'Host', stats[ 'host' ] ] )
      t.add_row( [ 'Error', numError, '', '' ] )
      t.add_row( [ 'Tests', numTests, '', '' ] )
      t.add_row( [ 'Tests ( exclude skip )', numNotSkip, '', '' ] )
      t.add_row( [ 'PassRate ( %d/%d )' % ( numPass, numNotSkip ), passRate,
                   '', '' ] )
      t.add_row( [ 'runTime', runTime, '', '' ] )
      print( t )

class ArjobUploader( object ):
   def __init__( self ):
      self.groupName = None
      self.projectName = None
      self.testServerName = None
      self.ownerName = None
      self.stats = None
      self.testCases = None
      self.target = None
      self.imageName = None
      self.topology = None

      self.testGroupJobId = None
      self.testResultToArjobResult = { 'success' : 'pass',
                                       'failure' : 'fail',
                                       'skipped' : 'na',
                                       'error' : 'error' }

   def generateNote( self ):
      stats = self.stats
      numPass = stats[ 'success' ]
      numFail = stats[ 'failure' ]
      numError = stats[ 'error' ]
      numSkip = stats[ 'skipped' ]
      runTime = stats[ 'runTime' ]

      numNotSkip = numPass + numFail + numError
      numTests = numNotSkip + numSkip
      passRate = str( numPass * 100 / numNotSkip if numNotSkip else 0 ) + '%'

      successStr = f'Success: {numPass}\n'
      failStr = f'Failure: {numFail}\n'
      skipStr = f'Skipped: {numSkip}\n'
      errorStr = f'Error: {numError}\n'
      testsStr = f'Tests: {numTests}\n'
      testsNotSkipStr = f'Tests ( exclude skip ): {numNotSkip}\n'
      passRateStr = f'PassRate ( {numPass}/{numNotSkip} ): {passRate}\n'

      return( successStr + failStr + skipStr + errorStr + testsStr +
              testsNotSkipStr + passRateStr )

   def createTestGroupJobEntry( self ):
      jobType = 'testgroup'
      name = self.groupName
      project = self.projectName
      package = self.package
      startTime = self.testCases[ 0 ].start
      endTime = startTime + self.stats[ 'runTime' ]
      host = self.testServerName
      parentJobId = None
      scheduler = self.ownerName
      target = self.target
      imageName = self.imageName
      result = 'pass'
      personality = self.topology
      note = self.generateNote()

      self.testGroupJobId = Arjob.recordJobStart(
         jobType=jobType, name=name, project=project, package=package,
         startTime=startTime, host=host, scheduler=scheduler, target=target,
         imageName=imageName )
      self.updateJob( self.testGroupJobId, note, personality )
      Arjob.updateJob( self.testGroupJobId, parentJobId=self.testGroupJobId )
      Arjob.recordJobEnd( self.testGroupJobId, endTime, result )

      args = (
         f'jobType={jobType}, name={name}, project={project}, package={package}, '
         f'startTime={startTime}, host={host}, scheduler={scheduler}, '
         f'target={target},imageName={imageName}, endTime={endTime}, '
         f'result={result}, personality={personality}, note={note}' )
      print( args )
      print( f'testGroupJobId={self.testGroupJobId}' )

   def createTestCaseJobEntry( self, testCase ):
      jobType = 'testcase'
      name = f'{self.package}/{testCase.filename}::{testCase.classname}::{testCase.testname}'
      project = self.projectName
      package = self.package
      startTime = testCase.start
      host = self.testServerName
      parentJobId = self.testGroupJobId
      scheduler = self.ownerName
      target = self.target
      imageName = self.imageName
      endTime = testCase.start + testCase.duration
      result = self.testResultToArjobResult[ testCase.status ]
      jobId = None
      personality = self.topology

      jobId = Arjob.recordJobStart(
         jobType=jobType, name=name, project=project, package=package,
         startTime=startTime, host=host, parentJobId=parentJobId,
         scheduler=scheduler, target=target, imageName=imageName )
      self.updateJob( jobId, personality=personality )
      Arjob.recordJobEnd( jobId, endTime, result )

      args = (
         f'jobType={jobType}, name={name}, project={project}, package={package}, '
         f'startTime={startTime}, host={host}, parentJobId={parentJobId}, '
         f'scheduler={scheduler}, target={target}, imageName={imageName}, '
         f'endTime={endTime}, result={result}, personality={personality}' )
      print( args )
      print( f'testCaseJobId={jobId}' )


   def createTestCaseJobEntries( self ):
      for testCase in self.testCases:
         self.createTestCaseJobEntry( testCase )

   def updateJob( self, jobId, note=None, personality=None ):
      Arjob.setupDjango()
      job = Arjob.Job.objects.get( id=jobId )

      if note:
         job.note = note
      if personality:
         job.personality = personality
      job.save()

   def upload( self, groupName, projectName, testServerName, ownerName,
               testCases, stats ):
      self.groupName = groupName
      self.projectName = projectName
      self.testServerName = testServerName
      self.ownerName = ownerName
      self.testCases = testCases
      self.stats = stats
      self.package = 'SonicMgmt'
      self.target = 'rdam://' + self.stats[ 'host' ]
      self.imageName = self.stats[ 'version' ]
      self.topology = self.stats[ 'topology' ]
      self.createTestGroupJobEntry()
      self.createTestCaseJobEntries()

def main():
   TestResultsProcessor( ArgProcessor(), TestResultsRenderer(), TestSummaryRenderer() )

if __name__ == '__main__':
   main()

