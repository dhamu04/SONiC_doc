# Copyright (c) 2024 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

import sys
import yaml

pathToTestbedFile = sys.argv[1]

with open(pathToTestbedFile,'r') as file:
   data = yaml.safe_load(file)

rootFanouts = []
leafFanouts = []
sonicDuts = []

runningConfig = {}

def printRunningConfig():
   for device in runningConfig:
      if device in sonicDuts:
         continue
      print(f"Device: {device}")
      print("IN CASE OF SHARED FANOUTS PROCEED WITH CAUTION")
      print("==============================================")
      print("--------------------")
      print()
      for config in runningConfig[device]:
         print(config)
      print("--------------------")
      print()

def getFanouts():
   devices = data["devices"]
   for device in devices:
      devType =  devices[device]["device_type"]
      if devType == "FanoutRoot" or devType == "FanoutLeaf" or devType == "DevSonic":
         runningConfig[device] = []
         if devType == "FanoutRoot":
            rootFanouts.append(device)
         elif devType == "FanoutLeaf":
            leafFanouts.append(device)
         elif devType == "DevSonic":
            sonicDuts.append(device)

def generateBfrCnfg(device):
   if device in sonicDuts:
      return
   runningConfig[device].append("platform trident mmu queue profile SonicMgmtProfile")
   for i in range(8):
      runningConfig[device].append(f"   egress unicast queue {i} threshold 8")
      runningConfig[device].append(f"   egress multicast queue {i} threshold 8")
   runningConfig[device].append("!")
   runningConfig[device].append("platform trident mmu queue profile SonicMgmtProfile apply")
   runningConfig[device].append("!")

def generateL2PrtclPktFwdCnfg(device):
   if device in sonicDuts:
      return
   runningConfig[device].append("no lldp run")
   runningConfig[device].append("!")
   runningConfig[device].append("mac address-table reserved forward 0180.c200.0002")
   runningConfig[device].append("mac address-table reserved forward 0180.c200.0003")
   runningConfig[device].append("mac address-table reserved forward 0180.c200.000e")
   runningConfig[device].append("!")

def generateVlanCfg(device):
   interfaces = data["topology"][device]["interfaces"]
   if device in sonicDuts:
      vlan_start = interfaces[list(interfaces.keys())[0]]["VlanID"]
      vlan_end = interfaces[list(interfaces.keys())[-1]]["VlanID"]
      # We are currently assuming that one DUT is entirely connected to a single leaf fanout,
      # so just check the first interface
      leafFanout = interfaces[list(interfaces.keys())[0]]["EndDevice"]
      for intf in interfaces:
         intfData = interfaces[intf]
         vlanId = intfData["VlanID"]
         intfName = intfData["EndPort"]
         runningConfig[leafFanout].append(f"interface {intfName}")
         runningConfig[leafFanout].append("   switchport mode dot1q-tunnel")
         runningConfig[leafFanout].append("   no switchport mac address learning")
         runningConfig[leafFanout].append(f"   switchport access vlan {vlanId}")
         runningConfig[leafFanout].append("!")

   elif device in leafFanouts:
      leafUplink = list(interfaces.keys())[0]
      vlanRange = interfaces[leafUplink]["VlanID"]

      # Vlan/STP Config
      runningConfig[device].append(f"vlan {vlanRange}")
      runningConfig[device].append("!")
      runningConfig[device].append("spanning-tree mode none")
      runningConfig[device].append(f"no spanning-tree vlan-id {vlanRange}")
      runningConfig[device].append("!")

      # Vlan Config for leafFanout uplink
      runningConfig[device].append(f"interface {leafUplink}")
      runningConfig[device].append(f"   switchport trunk allowed vlan {vlanRange}")
      runningConfig[device].append("   switchport mode trunk")
      runningConfig[device].append("   no switchport mac address learning")
      runningConfig[device].append("!")

      # Vlan Config for rootFanout downlink
      rootFanout = interfaces[leafUplink]["EndDevice"]
      rootDownlink = interfaces[leafUplink]["EndPort"]
      runningConfig[rootFanout].append(f"interface {rootDownlink}")
      runningConfig[rootFanout].append(f"   switchport trunk allowed vlan {vlanRange}")
      runningConfig[rootFanout].append("   switchport mode trunk")
      runningConfig[rootFanout].append("   no switchport mac address learning")
      runningConfig[rootFanout].append("!")

   elif device in rootFanouts:
      rootUplink = list(interfaces.keys())[0]
      vlanRange = interfaces[rootUplink]["VlanID"]

      # Vlan Config for rootFanout uplink
      runningConfig[device].append(f"vlan {vlanRange}")
      runningConfig[device].append("!")
      runningConfig[device].append("spanning-tree mode none")
      runningConfig[device].append(f"no spanning-tree vlan-id {vlanRange}")
      runningConfig[device].append("!")
      runningConfig[device].append(f"interface {rootUplink}")
      runningConfig[device].append(f"   switchport trunk allowed vlan {vlanRange}")
      runningConfig[device].append("   switchport mode trunk")
      runningConfig[device].append("   no switchport mac address learning")
      runningConfig[device].append("!")


def main():
   getFanouts()
   for device in rootFanouts + leafFanouts + sonicDuts:
      generateBfrCnfg(device)
      generateL2PrtclPktFwdCnfg(device)
      generateVlanCfg(device)

   printRunningConfig()
if __name__ == "__main__":
   main()
