import argparse
import datetime
import logging
import netifaces
import os
import paramiko
import pytz
import re
import shutil
import smtplib
import subprocess
import sys
import socket
import time

from datetime import datetime
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from common_utils import extract_no_of_tests

email_from = 'prakashkumar-ext@arista.com'
email_to = ["arista-calsoft-ext@arista.com"]

username = 'sonic'
test_directory = '/data/sonic-mgmt/tests'

console_log = 'auto_console.log'
script_log = 'auto_script.log'
num_subsets = 3

cwd = os.getcwd()

TESTBED_SETUP_DONE = False
SAVE_LOGS_DONE = False

logging.basicConfig(filename=script_log, level=logging.INFO, filemode='w', format='%(asctime)s - %(levelname)s - %(message)s')

class LogFilePaths:
    def __init__(self, source_dir, public_html, public_html_url, log_folder, log_file_path, output_file_path, sum_report_table, test_log_report, subset, topo_type, master_folder = None):
        self.source_log_dir = source_dir
        self.public_html_dir = public_html
        self.public_html_url = public_html_url
        self.log_folder = log_folder
        self.log_file_path = log_file_path
        self.output_file_path = output_file_path
        self.sum_report_table = sum_report_table
        self.test_log_report = test_log_report
        self.subset = subset
        self.topo_type = topo_type
        self.master_folder = master_folder

def ssh_connect(test_server, username):
    """ This function establishes an SSH connection to the server and returns the SSH client object."""
    ssh_server = paramiko.SSHClient()
    ssh_server.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        # Connect ssh server.
        ip = get_test_server_ip(test_server)
        ssh_server.connect(ip, username=username)
        logging.info("Ssh connection successfull")
        return ssh_server

    except Exception as e:
        logging.error(f"An error occurred while connecting to the SSH server: {e}")
        return None

def get_test_server_ip(test_server):
    try:
        ip = socket.gethostbyname(test_server)
        logging.info(f"Hostname {test_server} resolves to {ip}")
    except socket.error as err:
        logging.info(f"Error resolving hostname {test_server}: {err}")
    return ip

def get_sonic_mgmt_repo(source_path, ssh_server, release, setup_repo):

    if setup_repo:
        try:
            SonicMgmrRepo = f'mkdir {source_path} && cd {source_path} && curl https://gerrit.corp.arista.io/plugins/gitiles/arsonic/+/refs/heads/master/fixed-testbed/scripts/SonicMgmtRepoSetup.py?format=TEXT | base64 --decode > SonicMgmtRepoSetup.py; chmod +x SonicMgmtRepoSetup.py && ./SonicMgmtRepoSetup.py --branch {release}'
            stdin, stdout, stderr = ssh_server.exec_command(SonicMgmrRepo)
            exit_status = stdout.channel.recv_exit_status()

            if exit_status == 0:
                logging.info("Sonic-mgmt repo cloned successfully into test-server")
            else:
                logging.error(f"Command execution failed with exit status {exit_status}")
                return None

        except Exception as e:
            logging.error(f"Error while cloning sonic-mgmt repo: {e}")
            return None

def get_subsets(ssh_server, tc_name_or_folder, source_path):
    """ The function return subsets from number of directories from tests folder"""
    with ssh_server.open_sftp() as sftp:
        try:
            tests_directory = f'{source_path}/sonic-mgmt/tests/'
            sftp.listdir(tests_directory)
        except FileNotFoundError:
            raise FileNotFoundError(f"Tests directory '{tests_directory}' does not exist on the SSH server.")

        list_of_test_folders = sorted(entry.filename for entry in sftp.listdir_attr(tests_directory)
                             if entry.longname.startswith('d') or entry.filename.endswith('.py'))

    num_of_test_folders = len(list_of_test_folders)
    subset_group_size = num_of_test_folders // num_subsets
    extra_test_folders = num_of_test_folders % num_subsets

    group_folders = [list_of_test_folders[i*subset_group_size + min(i, extra_test_folders):(i+1)*subset_group_size + min(i+1, extra_test_folders)] for i in range(4)]

    subset_names_to_index = {'subset1': 0, 'subset2': 1, 'subset3': 2}
    subset_index = subset_names_to_index.get(tc_name_or_folder.lower(), 0)
    sub_sets = ' '.join(group_folders[subset_index])

    logging.info("subset : {sub_sets}")
    return sub_sets

def parse_arguments():
    """
    Parses command-line arguments are.
    1.topo_type : Topology types. Ex: mx, m0, dualtor etc.
    2.testbed_name : Name of the testbed
    3.option_tests_or_folder : Options are -c for single test case, -I for complete test folder or subsets and -s to skip the tests
    4.tc_or_folder : test case path or folder to be tested or subsets
    5.release : Active sonic-mgmt release
    6.test_server : test server on which topology is being deployed and run the test
    7.setup_repo : want to setup sonic-mgmt repo. True for yes, default is False
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--topo', type=str, choices={'m0', 'mx', 'dualtor'}, help='topology type: m0, mx, dualtor', required=True)
    parser.add_argument('-n', '--testbed_name', type=str, help='testbed name', required=True)
    parser.add_argument('-o', '--tc_option', type=str, choices={'c', 'I', 's'}, help='test case options: c, I, s', required=True)
    parser.add_argument('-f', '--tc_or_folder', type=str, help='single test case or folder, subsets', required=True)
    parser.add_argument('-r', '--rel', type=int, help='sonic mgmt release', required=True)
    parser.add_argument('-s', '--test_server', type=str, help='test-server', required=True)
    parser.add_argument('-g', '--setup_repo', type=bool, default=False, help='sonic-mgmt repo HEAD commit')

    args = parser.parse_args()

    topo_type = args.topo
    release = args.rel
    testcase_option = args.tc_option
    tc_name_or_folder = args.tc_or_folder
    testbed_name = args.testbed_name
    subset = tc_name_or_folder
    test_server = args.test_server
    setup_repo = args.setup_repo

    source_path = f'{testbed_name}_{release}'
    ssh_server = ssh_connect(test_server, username)
    get_sonic_mgmt_repo(source_path, ssh_server, release, setup_repo)

    if "subset" in str(tc_name_or_folder):
        sub_sets = get_subsets(ssh_server, tc_name_or_folder, source_path)
        tc_name_or_folder = sub_sets

    saithrift_url = '--py_saithrift_url=\"http://dist.sjc.aristanetworks.com/Sonic/202311/python-saithrift/python-saithrift_0.9.4_amd64.deb\"'
    topo_args = f'{topo_type},{topo_type}'

    if "dual" in str(topo_type):
        topo_args = topo_args + ',t0'

    if testcase_option in ['c']:
        command = f'sudo ./run_tests.sh -n {testbed_name} -{testcase_option} "{tc_name_or_folder}" -t any,util,{topo_args} -f ../ansible/testbed.yaml -e {saithrift_url}'
    else:
        command = f'sudo ./run_tests.sh -n {testbed_name} -{testcase_option} "{tc_name_or_folder}" -m individual -r -t any,util,{topo_args} -f ../ansible/testbed.yaml -e {saithrift_url}'

    # --collect-only command
    collect_command = f'sudo ./run_tests.sh -n {testbed_name} -t any,util,{topo_args} -y collect -u -f ../ansible/testbed.yaml'

    # Testbed setup commands.
    add_topo_cmd = f'./testbed-cli.sh -m veos -k ceos -t testbed.yaml add-topo {testbed_name} password.txt -vvv'
    deploymg_cmd = f'./testbed-cli.sh -t testbed.yaml deploy-mg {testbed_name} lab password.txt -vvv'
    remove_topo_cmd = f'./testbed-cli.sh -m veos -k ceos -t testbed.yaml remove-topo {testbed_name} password.txt -vvv'

    # Test case command.
    run_test_cmd = (command, test_directory)

    setup_cmd = [(add_topo_cmd, '/data/sonic-mgmt/ansible'), (deploymg_cmd, '/data/sonic-mgmt/ansible')]

    remove_topo = [(remove_topo_cmd, '/data/sonic-mgmt/ansible')]

    run_collect_test_cmd = (collect_command, test_directory)

    return run_test_cmd, setup_cmd, remove_topo, run_collect_test_cmd, source_path, topo_type, subset, ssh_server, test_server, release, testbed_name

def init_path(source_path, topo_type, subset, test_server, release, testbed_name):
    """this function cretes the path of different dirs used in following operations"""

    user_name, ip_address, public_html_dir = get_ip_and_user_name()
    test_server_ip = get_test_server_ip(test_server)
    source_log_dir_tst_server = f'{username}@{test_server_ip}:' + os.path.join(f'/home/sonic/', source_path, f'sonic-mgmt', 'tests', 'logs')
    public_html_url = f'http://{ip_address}/~{user_name}/'

    if "subset" not in subset:
        # Change the directory into public_html folder create the folder with curent date and time.
        os.chdir(public_html_dir)
        current_datetime = get_timezone()[0]

        log_folder = os.path.join(test_server, str(release), testbed_name, current_datetime)
        if not os.path.exists(log_folder):
            os.makedirs(log_folder)

        log_file_path = public_html_dir + log_folder

        test_sum_report_path = os.path.join(
                public_html_dir,
                log_folder,
                f'test_summary_report.txt'
                )

        sum_rpt_table = os.path.join(
                public_html_url,
                log_folder,
                f'test_summary_report.txt'
                )

        test_log_report = os.path.join(
                public_html_url,
                log_folder
                )

        os.chdir(cwd)

        logfilePathsObj = LogFilePaths(
                source_log_dir_tst_server, public_html_dir, public_html_url,
                log_folder, log_file_path, test_sum_report_path, sum_rpt_table,
                test_log_report, subset, topo_type
                )


    elif subset in ["subset1", "subset2", "subset3"]:

        master_folder = get_or_create_master_folder(subset, test_server, release, testbed_name)
        subset_folder = log_folder = create_subset_folder(master_folder, subset, topo_type)

        os.chdir(cwd)
        log_file_path = os.path.join(
                public_html_dir,
                master_folder,
                subset_folder
                )

        test_sum_report_path = os.path.join(
                public_html_dir,
                master_folder,
                subset_folder,
                subset + f'_test_summary_report.txt'
                )

        sum_rpt_table = os.path.join(
                public_html_url,
                master_folder,
                subset_folder,
                subset + f'_test_summary_report.txt'
                )

        test_log_report = os.path.join(
                public_html_url,
                master_folder,
                subset_folder
                )

        logfilePathsObj = LogFilePaths(
                source_log_dir_tst_server, public_html_dir,
                public_html_url, None, log_file_path,
                test_sum_report_path, sum_rpt_table, test_log_report,
                subset, topo_type, master_folder
                )

    logging.info(f"""Created paths:
                  source log directory : {source_log_dir_tst_server}
                  public html directory : {public_html_dir}
                  public html url : {public_html_url}
                  log file path : {log_file_path}""")

    return logfilePathsObj

def get_timezone():
    """This function get the current timezone"""

    datetime_now = datetime.now()
    current_datetime = datetime_now.strftime("%Y%m%d_%H%M%S")
    current_timezone = datetime.now(pytz.utc).astimezone().strftime('%Z')
    timezone = current_datetime +" " + current_timezone

    return current_datetime, timezone

def get_ip_and_user_name():
    """Get the user's home directory and IP address associated with the 'macvlan-bond0' interface"""

    user_name = os.environ.get('USER')
    try:
        addresses = netifaces.ifaddresses('macvlan-bond0')
        ip_address = addresses[netifaces.AF_INET][0]['addr']
    except (KeyError, ValueError, IndexError) as e:
        logging.error(f"Error: {e}")

    public_html_dir = os.path.join(f'/home', user_name, f'public_html/')

    return user_name, ip_address, public_html_dir

def create_docker_container(ssh_server):
    """This function creating the docker container"""

    new_docker = "cd /home/sonic/" + source_path + " && docker run -v /home/sonic/"+ source_path +":/data --name sonic-mgmt --network ip6net -p 80:80 -it -d docker-sonic-mgmt bash"
    stdin, stdout, stderr = ssh_server.exec_command(new_docker)
    output = stdout.read().decode()
    lines = output.strip().split('\n')
    container_id = lines[0]
    logging.info(f"New container created with ID: {container_id}")
    return container_id

def run_commands_and_collect_logs(ssh_server, container_id, full_command, mode ='a'):
    """Execute a command inside a Docker container via SSH and collect the output into a log file"""

    assert container_id, "Container ID is required"

    exec_command = f"docker exec -i {container_id} bash -c '{full_command}'"
    with open(console_log, mode) as file:
        channel = ssh_server.get_transport().open_session()
        channel.exec_command(exec_command)
        while True:
            output = channel.recv(4096).decode('utf-8')
            if not output:
                break
            file.write(output)
            print(output, end='')
        exit_code = channel.recv_exit_status()
        return exit_code

def remove_container(ssh_server, container_id):
    """This function remove the sonic-mgmt container with the specified container ID"""

    assert container_id, "Container ID is required"

    # Remove docker-sonic-mgmt container.
    remove_sonic_mgmt_container_cmd = f"docker stop {container_id} && docker rm -f {container_id}"
    stdin, stdout, stderr = ssh_server.exec_command(remove_sonic_mgmt_container_cmd)
    remove_container_err_msg = stderr.read().decode().strip()

    if remove_container_err_msg :
        logging.error(f"Error while removing docker-sonic-mgmt container: {remove_container_err_msg}")
        return False

    logging.info(f"docker-sonic-mgmt container with ID {container_id} removed successfully.")
    return True

def execute_test(ssh_server, container_id, *args):
    """This function get into the sonic-mgmt container and execute the tests"""

    run_command =[]

    for arg in args:
        run_cmd, target_directory = arg
        full_command = f'cd {target_directory} && {run_cmd}'
        test_start_time = get_timezone()[1]

        logging.info(f"running test command : {run_cmd}")
        exit_code = run_commands_and_collect_logs(ssh_server, container_id, full_command)

        if  exit_code == 0:
            logging.info(f"Run command '{run_cmd}' successfully completed in '{target_directory}'")
        else:
            logging.error(f"Run command '{run_cmd}' not successfully done in in '{target_directory}, exist_status:'{exit_code}'")
    test_end_time = get_timezone()[1]
    run_command.append(run_cmd)

    return run_command, test_start_time, test_end_time

def testbed_setup(ssh_server, container_id, *args, mode):
    """This function get into the sonic-mgmt container and does the testbed setup"""

    for cmd, target_directory in args:
        full_command = f'cd {target_directory} && {cmd}'

        logging.info(f"running testbed setup command : {cmd}")
        exit_code = run_commands_and_collect_logs(ssh_server, container_id, full_command, mode)

        if exit_code == 0:
            logging.info(f"Setup command '{cmd}' successfully completed in '{target_directory}'")
            global TESTBED_SETUP_DONE
            TESTBED_SETUP_DONE = True
        else:
            logging.error(f"Setup command '{cmd}' not successfully done in '{target_directory}', exits_status:'{exit_code}'")
            raise ValueError(f"testbed_setup() failed : {cmd}")
            break
        time.sleep(5)

def execute_collect_only(ssh_server, container_id, subset, *args):
    """Execute command to get total number of tests"""

    if subset not in ["subset1", "subset2"]:
        for arg in args:
            run_cmd, target_directory = arg
            full_command = f'cd {target_directory} && {run_cmd}'
            logging.info(f"running command command : {run_cmd}")

            exit_code = run_commands_and_collect_logs(ssh_server, container_id, full_command)
            if  exit_code == 0:
                logging.info(f"Run command '{run_cmd}' successfully completed in '{target_directory}'")
                total_tests = extract_no_of_tests(console_log)
                logging.info(f"Total number of test : {total_tests}")
            else:
                logging.error(f"Run command '{run_cmd}' not successfully done in in '{target_directory}, exist_status:'{exit_code}'")

def create_master_folder(test_server, release, testbed_name):
    """ Check if master folder exists, if not, create it with topo-type and current timestamp"""

    user_name, ip_address, public_html_dir = get_ip_and_user_name()

    # Create master folder.
    os.chdir(public_html_dir)
    current_datetime = get_timezone()[0]
    current_datetime = f'{current_datetime}_subsets'
    master_folder = os.path.join(test_server, str(release), testbed_name, current_datetime)

    os.makedirs(master_folder, exist_ok=True)

    # Create log folder inside master folder.
    logs_folder = os.path.join(master_folder, "logs")
    os.makedirs(logs_folder, exist_ok=True)

    return master_folder

def get_or_create_master_folder(subset, test_server, release, testbed_name):
    """ creating the master_folder newly if subset1 or else get the most recently created master folder"""

    user_name, ip_address, public_html_dir = get_ip_and_user_name()
    master_folder = None

    if subset == "subset1":
        master_folder = create_master_folder(test_server, release, testbed_name)
    elif subset in ['subset2', 'subset3']:
        base_dir = os.path.join(test_server, str(release), testbed_name)
        os.chdir(public_html_dir + base_dir)

        master_folders = [folder for folder in os.listdir(public_html_dir + base_dir) if folder.endswith(f'_subsets')]
        assert master_folders, "No folder found that ends with _subsets."

        master_folder = os.path.join(base_dir, sorted(master_folders, reverse=True)[0])

    return master_folder

def create_subset_folder(master_folder, subset, topo_type):
    """ create subset folder inside the most recently created master folder"""

    user_name, ip_address, public_html_dir = get_ip_and_user_name()

    os.chdir(public_html_dir + master_folder)
    os.makedirs(subset)

    subset_log_folder = os.path.join(subset, "logs")
    os.makedirs(subset_log_folder, exist_ok=True)

    return subset

def copy_logs_from_test_server(source, dest):
    """ copy the test logs to public html folder"""

    try:
        result_scp = subprocess.run(['scp', '-r', source, dest], check=True, capture_output=True, text=True)
        logging.info("Files copied successfully into public_html folder. Output: %s", result_scp.stdout)
    except subprocess.CalledProcessError as e:
        logging.error("SCP command failed with exit code: %s. Error: %s", e.returncode, e.stderr)
        raise ValueError("copy_logs_from_test_server() : SCP command failed") from e

def generate_summary_reports(output_file_path, log_folder):
    """ This function generate the test summary report"""

    current_directory = os.getcwd()

    try:
        with open(output_file_path, 'w') as output_file:
            result_translate = subprocess.run(['python3', 'sonic-translate.py', f'{log_folder}/logs/'],
                                              stdout=output_file, stderr=subprocess.STDOUT, text=True)
            if result_translate.returncode == 0:
                logging.info("Test summary report generated successfully.")
            else:
                logging.error(f"Error during test summary report preparations. Return code: {result_translate.returncode}")
    except Exception as e:
        logging.error(f"Exception occurred while generating summary report: {e}")

    return output_file_path

def copy_and_save_logs(logFilePathObj):
    """
    This function getting into the logs folder and generate the summary report
    if its subsets  getting into the subset_folder and generate the summary report
    """
    if "subset" not in logFilePathObj.subset:

        # Copy the test logs folder into public_html folder where created folder with current date and time.

        copy_logs_from_test_server(logFilePathObj.source_log_dir, logFilePathObj.log_file_path)
        os.chdir(logFilePathObj.public_html_dir)
        generate_summary_reports(logFilePathObj.output_file_path, logFilePathObj.log_file_path)

    else:
        if logFilePathObj.subset in ["subset1", "subset2", "subset3"]:
            copy_logs_from_test_server(logFilePathObj.source_log_dir, logFilePathObj.log_file_path)
            command = f"cp -r {logFilePathObj.log_file_path}/logs/* {logFilePathObj.public_html_dir}/{logFilePathObj.master_folder}/logs/"
            subprocess.run(command, shell=True, check=True)
            os.chdir(logFilePathObj.public_html_dir)
            generate_summary_reports(logFilePathObj.output_file_path, logFilePathObj.log_file_path)

    global SAVE_LOGS_DONE
    SAVE_LOGS_DONE = True

def prepare_email_body(output_file_path, sum_rpt_table, test_log_report, run_command, test_start_time, test_end_time, err=None):
    """This function prepares the email body"""

    email_body =''

    if err is None:
        with open(output_file_path, 'r') as output_file:
            output_contents = output_file.readlines()

            # filter out the failure/error test cases.
            err_cases = ''
            for line in output_contents:
                if "error" in line or "failure" in line:
                    err_cases += line.strip() + '\n'

            output_file.seek(0)
            output_string = ''.join(output_contents)
            summary_table_pattern = r'(\+[-+]+\+\n.+?\n\+[-+]+)'
            match = re.search(summary_table_pattern, output_string, re.DOTALL)

            if match:
                summary_table = match.group(1)
                logging.info(f"Test Summary Table:\n{summary_table}")

                email_body = f"""
                <html>
                    <body>
                        <p>Hi Team,</p>
                        <p>     Please find the extracted summary table and logs.</p>

                        <p> Executed run Command : {run_command}</p>
                        <p> Test start time : {test_start_time}</p>
                        <p>  Test end time : {test_end_time}</p>

                        <pre>{summary_table}</pre>

                        <p> <strong> Test Summary report is available at:</strong> {sum_rpt_table} </p>
                        <p><strong> Test logs report is available at: </strong>{test_log_report} </p>
                        <p> <strong> Failed test cases:</strong> </p>
                        <pre>{err_cases}</pre>
                    </body>
                </html>
                """
    else:
        email_body = f"""
        <html>
            <body>
                <p> Hi Team, </p>
                <p> Test Failed at: {err}</p>

                <p><strong> Test logs report is available at: </strong>{test_log_report} </p>
            </body>
        </html>
        """
    return email_body

def send_email_notifications(logFilePathObj, run_command, test_start_time, test_end_time, subset, err = None):
    """This function send out email notifications with test summary report"""

    # Check if script is executed from cli or cronjob.
    job_type = 'manual' if sys.stdin.isatty() else 'cronjob'

    recipients = email_to
    if "subset" in subset:
        subject = f"Test Summary Report: {logFilePathObj.topo_type} | job type: {job_type} | {subset}"
    else:
        subject = f"Test Summary Report: {logFilePathObj.topo_type} | job type: {job_type}"

    message = MIMEMultipart()
    message['From'] = email_from
    message['To'] = ", ".join(recipients)
    message['Subject'] = subject

    # This is success scenario where all the steps executed successfully.
    if TESTBED_SETUP_DONE and SAVE_LOGS_DONE:

        email_body = prepare_email_body(logFilePathObj.output_file_path, logFilePathObj.sum_report_table, logFilePathObj.test_log_report, run_command[0], test_start_time, test_end_time, err)

        message.attach(MIMEText(email_body, 'html'))

        with open(logFilePathObj.output_file_path, 'r') as output_file:
            attachment = MIMEText(output_file.read())
            attachment.add_header('Content-Disposition', 'attachment', filename='Test_summary_report.txt')
            message.attach(attachment)
    else:
        # In case any error in between the test, will send the error in the email.
        email_body  = prepare_email_body(None, None, logFilePathObj.test_log_report, None, None, None, err)
        message.attach(MIMEText(email_body, 'html'))

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(email_from, "rojm ikga awnl foou")
            server.sendmail(email_from, recipients, message.as_string())
            logging.info("email sent successfully")

    except Exception as e:
        logging.error("error while sending email:", e)

    subprocess.run(['cp','-r', script_log, logFilePathObj.log_file_path], cwd=cwd, check=True)
    subprocess.run(['cp','-r', console_log, logFilePathObj.log_file_path], cwd=cwd, check=True)

def test_summary_report_final(logFilePathObj, subset):
    """ This function generate the consolidated test summary report for all subsets"""

    if subset == 'subset3':

        output_file_path = os.path.join(
                logFilePathObj.public_html_dir,
                logFilePathObj.master_folder,
                f'logs',
                f'final_test_summary_report.txt'
                )

        sum_rpt_table = os.path.join(
                logFilePathObj.public_html_url,
                logFilePathObj.master_folder,
                f'logs',
                f'final_test_summary_report.txt'
                )

        test_log_report = os.path.join(
                logFilePathObj.public_html_url,
                logFilePathObj.master_folder
                )

        log_folder = os.path.join(
                logFilePathObj.public_html_dir,
                logFilePathObj.master_folder
                )

        current_working_dir = os.getcwd()
        os.chdir(logFilePathObj.public_html_dir)
        generate_summary_reports(output_file_path, log_folder)

        with open(output_file_path, 'r') as output_file:
            output_contents = output_file.read()

            pass_rate_pattern = r"PassRate\s*\(\s*(\d+)/(\d+)\s*\)\s*\|\s*([\d.]+)%"
            pass_rate_match = re.search(pass_rate_pattern, str(output_contents))

            if pass_rate_match:
                pass_rate = float(pass_rate_match.group(3))
                print("Pass Rate:", pass_rate)
            else:
                print("Pass Rate not found in summary table.")
                logging.info(f"Test Summary Table:\n{summary_table}")

        job_type = 'manual' if sys.stdin.isatty() else 'cronjob'
        recipients = email_to

        subject = f"Final_Test Report: {logFilePathObj.topo_type} | job type: {job_type} | pass rate:{pass_rate}%"

        message = MIMEMultipart()
        message['From'] = email_from
        message['To'] = ", ".join(recipients)
        message['Subject'] = subject

        email_body  = prepare_email_body(output_file_path, sum_rpt_table, test_log_report, None, None, None, None)

        message.attach(MIMEText(email_body, 'html'))

        with open(logFilePathObj.output_file_path, 'r') as output_file:
            attachment = MIMEText(output_file.read())
            attachment.add_header('Content-Disposition', 'attachment', filename='Test_summary_report.txt')
            message.attach(attachment)

        try:
            with smtplib.SMTP('smtp.gmail.com', 587) as server:
                server.starttls()
                server.login(email_from, "rojm ikga awnl foou")
                server.sendmail(email_from, recipients, message.as_string())
                logging.info("email sent successfully")

        except Exception as e:
            logging.error("error while sending email:", e)

# Fetch the arguments
run_test_cmd, setup_cmd, remove_topo, run_collect_test_cmd, source_path, topo_type, subset, ssh_server, test_server, release, testbed_name = parse_arguments()

logFilePathObj = init_path(source_path, topo_type, subset, test_server, release, testbed_name)

try:
    # Create the sonic-mgmt docker conatiner.
    container_id = create_docker_container(ssh_server)

    # Complete the testbed setup.
    test_setup = testbed_setup(ssh_server, container_id, *setup_cmd, mode='w')

    # Run the specified test case.
    run_command_result = execute_test(ssh_server, container_id, run_test_cmd)

    # After the test save the logs and generate the report.
    copy_and_save_logs(logFilePathObj)

    # Execute --collect-only to get the total number of test
    execute_collect_only(ssh_server, container_id, subset, run_collect_test_cmd)

    # Remove the topology
    remove_topology = testbed_setup(ssh_server, container_id, *remove_topo, mode='a')

    # Remove the docker-sonic-mgmt container.
    remove_container(ssh_server, container_id)

    # Send email to specified recepients.
    send_email_notifications(logFilePathObj, run_command_result[0], run_command_result[1], run_command_result[2], subset)

    time.sleep(5)
    # Send final summary report.
    test_summary_report_final(logFilePathObj, subset)

except Exception as e:
    logging.error("exception occurred, skipping next steps")
    try:
        remove_topology = testbed_setup(ssh_server, container_id, *remove_topo, mode='a')
        remove_container(ssh_server, container_id)
        send_email_notifications(logFilePathObj, None, None, None, subset, e)
    except Exception as nested_err:
        logging.error("exception occurred : remove_topo/remove_container failed.")
        send_email_notifications(logFilePathObj, None, None, None, subset, nested_err)
