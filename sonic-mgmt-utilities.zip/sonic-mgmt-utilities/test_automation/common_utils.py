import re

def extract_no_of_tests(log_file):
    # Regular expression pattern to match the tests collected
    pattern = r'\d+/\d+ tests collected'

    try:
        with open(log_file, 'r') as file:
            for line in file:
                match = re.search(pattern, line)
                if match:
                    #Extract the number
                    tests_collected = match.group().split('/')[1].split()[0]
                    file.close()
                    return tests_collected
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")


